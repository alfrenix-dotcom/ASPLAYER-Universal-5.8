"""Self-contained UI smoke tests, using mocked data; not Android codec tests."""
from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent.parent / 'app/src/main/assets'
bridge=(Path(__file__).resolve().parent/'mock_bridge.js').read_text()
with sync_playwright() as pl:
 browser=pl.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':820,'height':1050})
 context.add_init_script(script=bridge)
 page=context.new_page()
 page.set_default_timeout(12000)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 html=(p/'index.html').read_text()
 for asset in sorted(p.glob('*.js')):
  html=html.replace('<script src="'+asset.name+'"></script>', '<script>'+asset.read_text()+'</script>')
 page.evaluate("window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__store[k]??null,setItem:(k,v)=>{window.__store[k]=String(v)},removeItem:k=>delete window.__store[k]}})")
 page.set_content(html,wait_until='load')
 page.locator('#username').fill('testuser')
 page.locator('#password').fill('testpass')
 page.locator('#login-button').click()
 page.locator('#view-home').wait_for(state='visible')
 page.locator('aside [data-nav="vod"]').click()
 page.locator('#categories [data-category="11"]').wait_for()
 page.locator('#categories [data-category="11"]').click()
 page.locator('#cards .tile').first.wait_for()
 page.locator('#cards .tile').first.click()
 page.locator('#detail-actions button').first.click()
 page.wait_for_timeout(250)
 assert any(x[0]=='media' for x in page.evaluate('window.__native')),page.evaluate('window.__native')
 assert page.locator('#modern-player').is_hidden()
 print('PASS VOD directed to LibVLC native bridge')
 page.evaluate('window.ASPLAYER58_EVENT({type:"position",position:61000,duration:180000,ended:false})')
 pos=page.evaluate("JSON.parse(localStorage.getItem('asplayer:history:v5.2'))['anubis|testuser|'].vod.find(x=>x.id==='201')?.position")
 assert pos>=61,pos
 print('PASS LibVLC native playback progress saved to 5.7.1 history')
 page.evaluate('window.ASPLAYER58_EVENT({type:"closed"})')
 page.locator('aside [data-nav="settings"]').click()
 page.locator('input[name="play-profile"][value="ultra"]').check()
 assert page.evaluate("JSON.parse(localStorage.getItem('asplayer:settings:v5.2')).bufferProfile")=='ultra'
 print('PASS Ultra profile persisted')
 page.locator('aside [data-nav="live"]').click()
 page.locator('#categories [data-category="all"]').wait_for()
 page.locator('#categories [data-category="all"]').click()
 page.locator('#cards .tile').first.wait_for()
 page.locator('#cards .tile').first.click()
 assert any(x[0]=='mini' for x in page.evaluate('window.__native'))
 assert not any(a[0].startswith('get_short_epg') or a[0]=='get_simple_data_table' for a in page.evaluate('window.__actions'))
 print('PASS live TV uses native LibVLC bridge; no EPG calls')
 assert not errors,errors
 print('PASS no JavaScript runtime errors')
 browser.close()
