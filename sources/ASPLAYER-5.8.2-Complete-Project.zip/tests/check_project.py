from pathlib import Path
root=Path(__file__).resolve().parents[1]
activity=(root/'app/src/main/java/com/alftech/asplayer/universal/MainActivity.java').read_text()
gradle=(root/'app/build.gradle').read_text()
assert 'org.videolan.libvlc.LibVLC' in activity
assert "libvlc-all:3.7.7" in gradle
assert 'startMediaInternal' in activity and 'setHWDecoderEnabled' in activity
assert 'getAllAudioTracks' in activity and 'getAllSpuTracks' in activity
assert 'setPlaybackOptions' in activity and 'playMedia' in activity
assert 'media.addOption(":network-caching="' in activity
assert 'getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE)' in activity
assert 'requestAsync' in activity
for name in ['index.html','app.js','features-5.8.js']:
    assert (root/'app/src/main/assets'/name).exists()
print('Static source checks passed (NOT a Gradle compile or playback test).')
