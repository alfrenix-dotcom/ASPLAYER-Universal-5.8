# Third-party notices

This experimental source is designed to use VideoLAN LibVLC via `org.videolan.android:libvlc-all:3.7.7`.
LibVLC is published under GNU LGPL v2.1 or later for Android bindings as declared by its artifacts.
Review the exact library and its transitive dependencies and follow the license/notice/source obligations before distributing a compiled APK.
The project does not contain IPTV Smarters Pro code or its branded assets.
