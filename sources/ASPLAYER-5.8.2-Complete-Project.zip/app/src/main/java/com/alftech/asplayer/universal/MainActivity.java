package com.alftech.asplayer.universal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityNotFoundException;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

/**
 * LibVLC-based experimental ASPLAYER 5.8 variant.
 * No IPTV Smarters Pro proprietary code or assets are used.
 * The APK must be compiled and field-tested before distribution.
 */
public final class MainActivity extends Activity {
    private static final Set<String> PROVIDERS = new HashSet<>(Arrays.asList(
            "kp-thebestiptv.com", "play.pelusa.online", "liontv.es"));
    private static final int IMMERSIVE = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
    private FrameLayout root;
    private WebView web;
    private VLCVideoLayout video;
    private LinearLayout controls;
    private Button playPause;
    private LibVLC vlc;
    private MediaPlayer player;
    private boolean attached;
    private boolean playerVisible;
    private boolean isLive;
    private boolean triedLiveFallback;
    private String playingUrl="";
    private String profile="normal", pictureMode="cover", audioLanguage="auto", subtitleLanguage="off";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService requests = Executors.newFixedThreadPool(3);
    private final Runnable hideControls = () -> { if(controls != null && playerVisible) controls.setVisibility(View.GONE); };
    private final Runnable progressTicker = new Runnable() {
        @Override public void run() {
            if(playerVisible && player != null) { sendPosition(false); handler.postDelayed(this,5000); }
        }
    };

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,15,34));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"file".equalsIgnoreCase(r.getUrl().getScheme());
            }
        });
        web.addJavascriptInterface(new Bridge(), "ASPLAYER");
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        video = new VLCVideoLayout(this);
        video.setVisibility(View.GONE);
        root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        video.setOnClickListener(v -> showControls());
        createControls();
        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
        // Use a maintained stable LibVLC dependency, without shipping codecs separately.
        vlc = new LibVLC(this, new ArrayList<>());
        player = new MediaPlayer(vlc);
        player.setEventListener(e -> handler.post(() -> {
            if(!playerVisible) return;
            switch(e.type) {
                case MediaPlayer.Event.Playing:
                    sendEvent("ready");
                    handler.postDelayed(this::refreshTrackMetadata,1000);
                    break;
                case MediaPlayer.Event.Buffering: sendEvent("buffering"); break;
                case MediaPlayer.Event.EndReached: sendPosition(true); sendEvent("ended"); break;
                case MediaPlayer.Event.EncounteredError:
                    if(!triedLiveFallback && isLive && playingUrl.toLowerCase(Locale.ROOT).endsWith(".m3u8")) {
                        triedLiveFallback = true;
                        startMediaInternal(playingUrl.substring(0,playingUrl.length()-5)+".ts",0);
                    } else sendEvent("error");
                    break;
                default: break;
            }
        }));
    }

    private int dp(float value) { return Math.round(value*getResources().getDisplayMetrics().density); }
    private Button button(String title, Runnable callback) {
        Button b=new Button(this);
        b.setText(title);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setAllCaps(false);
        b.setBackgroundColor(0xB523174A);
        b.setOnClickListener(v -> { callback.run(); showControls(); });
        return b;
    }
    private void createControls() {
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setBackgroundColor(0x88050B1C);
        playPause=button("Pause",()-> {
            if(player==null)return;
            if(player.isPlaying())player.pause(); else player.play();
            playPause.setText(player.isPlaying()?"Pause":"Play");
        });
        controls.addView(button("−10s",()-> seekBy(-10000)),new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(playPause,new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(button("+10s",()-> seekBy(10000)),new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(button("Audio",()-> chooseTrack(false)),new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(button("Subs",()-> chooseTrack(true)),new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(button("Fit/Fill",()-> toggleAspect()),new LinearLayout.LayoutParams(0,dp(52),1));
        controls.addView(button("✕",()-> closePlayer(true)),new LinearLayout.LayoutParams(0,dp(52),.6f));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(54),Gravity.BOTTOM);
        root.addView(controls,lp);
        controls.setVisibility(View.GONE);
    }
    private void showControls() {
        if(!playerVisible)return;
        controls.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideControls);
        handler.postDelayed(hideControls,3000);
    }
    private void seekBy(long delta) {
        if(player==null || isLive) return;
        long t=player.getTime(),len=player.getLength();
        if(t>=0) player.setTime(len>0?Math.min(len,Math.max(0,t+delta)):Math.max(0,t+delta));
    }
    private boolean allowedProviderUrl(String raw, boolean media) {
        try {
            Uri u=Uri.parse(raw);
            String host=u.getHost();
            if(host==null || !PROVIDERS.contains(host.toLowerCase(Locale.ROOT)))return false;
            if(!"http".equalsIgnoreCase(u.getScheme()) && !"https".equalsIgnoreCase(u.getScheme()))return false;
            if(!media)return "/player_api.php".equals(u.getPath());
            String p=u.getPath();
            return p!=null && (p.startsWith("/live/") || p.startsWith("/movie/") || p.startsWith("/series/"));
        } catch(Exception ignored) { return false; }
    }
    private int networkCache() {
        if("fast".equals(profile))return 1000;
        if("ultra".equals(profile))return 9000;
        return 4000;
    }
    private void updateAspect() {
        if(player==null)return;
        boolean portrait=getResources().getConfiguration().orientation==Configuration.ORIENTATION_PORTRAIT;
        // The supported LibVLC ScaleType names vary; use reflection for graceful fallback.
        String requested = portrait || "contain".equals(pictureMode)?"SURFACE_BEST_FIT"
                : "fill".equals(pictureMode)?"SURFACE_FILL":"SURFACE_FIT_SCREEN";
        try {
            Class<?> type=Class.forName("org.videolan.libvlc.MediaPlayer$ScaleType");
            Object enumValue;
            try { enumValue=Enum.valueOf((Class)type,requested); }
            catch(Exception missing) { enumValue=Enum.valueOf((Class)type,"SURFACE_BEST_FIT"); }
            player.getClass().getMethod("setVideoScale",type).invoke(player,enumValue);
        } catch(Exception ignored) { /* default fit if this LibVLC release differs */ }
    }
    private void toggleAspect() { pictureMode="contain".equals(pictureMode)?"cover":"contain"; updateAspect(); }
    private void startMedia(String url,String newProfile,String aspect,String audio,String subs,long resumeMs) {
        if(!allowedProviderUrl(url,true)) { sendEvent("error"); return; }
        this.profile="fast".equals(newProfile)||"ultra".equals(newProfile)?newProfile:"normal";
        this.pictureMode=aspect; this.audioLanguage=audio; this.subtitleLanguage=subs;
        this.playingUrl=url; this.triedLiveFallback=false;
        startMediaInternal(url,resumeMs);
    }
    private void startMediaInternal(String url,long resumeMs) {
        if(player==null)return;
        isLive=url.contains("/live/");
        try {
            player.stop();
            if(!attached) {
                player.attachViews(video,null,true,false);
                attached=true;
            }
            Media media=new Media(vlc,Uri.parse(url));
            media.setHWDecoderEnabled(true,false);
            media.addOption(":network-caching="+networkCache());
            media.addOption(":live-caching="+networkCache());
            media.addOption(":file-caching="+networkCache());
            player.setMedia(media);
            media.release();
            playerVisible=true;
            video.setVisibility(View.VISIBLE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE);
            updateAspect();
            handler.removeCallbacks(progressTicker);
            handler.postDelayed(progressTicker,5000);
            player.play();
            if(resumeMs>0 && !isLive)handler.postDelayed(()->{if(playerVisible && player!=null) player.setTime(resumeMs);},700);
            showControls();
        } catch(Exception error) { sendEvent("error"); }
    }
    private void sendEvent(String name) {
        try { JSONObject x=new JSONObject(); x.put("type",name); sendEvent(x); } catch(Exception ignored) { }
    }
    private void sendEvent(JSONObject obj) { evaluate("window.ASPLAYER58_EVENT&&window.ASPLAYER58_EVENT("+obj+");"); }
    private void sendPosition(boolean ended) {
        if(!playerVisible || player==null)return;
        try {
            JSONObject e=new JSONObject();
            e.put("type","position");e.put("position",Math.max(0,player.getTime()));
            e.put("duration",Math.max(0,player.getLength()));e.put("ended",ended);
            sendEvent(e);
        } catch(Exception ignored) { }
    }
    private void evaluate(String js) { runOnUiThread(()->{if(web!=null)web.evaluateJavascript(js,null);}); }
    private void closePlayer(boolean notifyWeb) {
        sendPosition(false);
        playerVisible=false;
        handler.removeCallbacks(hideControls);
        handler.removeCallbacks(progressTicker);
        if(player!=null)player.stop();
        if(controls!=null)controls.setVisibility(View.GONE);
        if(video!=null)video.setVisibility(View.GONE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        if(notifyWeb)sendEvent("closed");
    }
    private static Object invokeNoArgs(Object o,String name) {
        try { return o.getClass().getMethod(name).invoke(o); }catch(Exception ignored){return null;}
    }
    private static String trackProp(Object t,String getter,String field) {
        Object v=invokeNoArgs(t,getter);
        if(v!=null)return String.valueOf(v);
        try {Field f=t.getClass().getField(field);Object x=f.get(t);return x==null?"":String.valueOf(x);}
        catch(Exception ignored){return "";}
    }
    private static final class TrackOption { final String id; final String label;
        TrackOption(String i,String l){id=i;label=l;}}
    private List<TrackOption> tracks(boolean subtitles) {
        ArrayList<TrackOption> out=new ArrayList<>();
        if(subtitles)out.add(new TrackOption("-1","Off / Desactivados"));
        if(player==null)return out;
        Object all=invokeNoArgs(player,subtitles?"getAllSpuTracks":"getAllAudioTracks");
        if(all==null)all=invokeNoArgs(player,subtitles?"getSpuTracks":"getAudioTracks");
        if(all instanceof Object[]) {
            for(Object t:(Object[])all) {
                String id=trackProp(t,"getId","id");
                String name=trackProp(t,"getName","name");
                if(name.isEmpty())name=trackProp(t,"getDescription","description");
                if(id.isEmpty())continue;
                out.add(new TrackOption(id,name.isEmpty()?"Track "+id:name));
            }
        }
        return out;
    }
    private void chooseTrack(boolean subtitles) {
        List<TrackOption> options=tracks(subtitles);
        if(options.isEmpty() || (subtitles && options.size()==1)) {
            Toast.makeText(this,subtitles?"No subtitles available":"No alternate audio available",Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels=new String[options.size()];
        for(int i=0;i<options.size();i++)labels[i]=options.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(subtitles?"Subtitles / Subtítulos":"Audio / Idioma")
                .setItems(labels,(d,which)-> selectTrack(subtitles,options.get(which).id))
                .setNegativeButton("Cancel",null).show();
    }
    private void selectTrack(boolean subtitles,String id) {
        if(player==null)return;
        try {
            String method=subtitles?"setSpuTrack":"setAudioTrack";
            try { player.getClass().getMethod(method,String.class).invoke(player,id); }
            catch(NoSuchMethodException old) { player.getClass().getMethod(method,int.class).invoke(player,Integer.parseInt(id)); }
        } catch(Exception error) {
            Toast.makeText(this,"Track not supported by this stream",Toast.LENGTH_SHORT).show();
        }
    }
    private void refreshTrackMetadata() {
        if(!playerVisible)return;
        try {
            JSONObject e=new JSONObject().put("type","tracks");
            e.put("audioCount",tracks(false).size());
            e.put("subtitleCount",Math.max(0,tracks(true).size()-1));
            sendEvent(e);
        }catch(Exception ignored){}
    }
    private final class Bridge {
        @JavascriptInterface public void play(String url) {
            runOnUiThread(()->startMedia(url,profile,pictureMode,audioLanguage,subtitleLanguage,0));
        }
        @JavascriptInterface public void setPlaybackOptions(String p,String a,String audio,String subs) {
            runOnUiThread(()->{profile=p;pictureMode=a;audioLanguage=audio;subtitleLanguage=subs;updateAspect();});
        }
        @JavascriptInterface public void playMini(String url) {play(url);}
        @JavascriptInterface public void resizeMini(boolean full) { }
        @JavascriptInterface public void stopMini() {stopMedia();}
        @JavascriptInterface public void stopMedia() {runOnUiThread(()->closePlayer(false));}
        @JavascriptInterface public void playMedia(String url,String p,String a,String audio,String subs,long pos) {
            runOnUiThread(()->startMedia(url,p,a,audio,subs,pos));
        }
        @JavascriptInterface public void playExternal(String url) {
            if (!allowedProviderUrl(url, true)) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.parse(url), "video/*");
                try { startActivity(intent); }
                catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this, "No compatible player installed", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void openLink(String raw) {
            if (!raw.startsWith("https://www.alftechsolutions.com/")
                    && !raw.startsWith("https://wa.me/12367021555")
                    && !raw.startsWith("mailto:company@alftechsolutions.com")
                    && !raw.startsWith("tel:+12367021555")) return;
            runOnUiThread(() -> {
                Intent i = new Intent(raw.startsWith("mailto:") ? Intent.ACTION_SENDTO
                        : raw.startsWith("tel:") ? Intent.ACTION_DIAL : Intent.ACTION_VIEW, Uri.parse(raw));
                try { startActivity(i); } catch (ActivityNotFoundException ignored) { }
            });
        }
        @JavascriptInterface public void requestAsync(String raw, String id) {
            requests.execute(() -> {
                String response = "{}";
                HttpURLConnection connection = null;
                try {
                    Uri uri = Uri.parse(raw);
                    boolean provider = allowedProviderUrl(raw, false);
                    boolean secureBackend = "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
                    if (!provider && !secureBackend) throw new SecurityException("Request not allowed");
                    connection = (HttpURLConnection) new URL(raw).openConnection();
                    connection.setConnectTimeout(9000);
                    connection.setReadTimeout(28000);
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Accept-Encoding", "gzip");
                    connection.setInstanceFollowRedirects(false);
                    int status = connection.getResponseCode();
                    if (status < 200 || status >= 300) throw new Exception("Server HTTP " + status);
                    InputStream rawStream = connection.getInputStream();
                    InputStream decoded = "gzip".equalsIgnoreCase(connection.getContentEncoding())
                            ? new GZIPInputStream(rawStream) : rawStream;
                    try (InputStream in = decoded; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                        byte[] bytes = new byte[8192];
                        int count, total = 0;
                        while ((count = in.read(bytes)) != -1) {
                            total += count;
                            if (total > 40 * 1024 * 1024) throw new Exception("Server response too large");
                            output.write(bytes, 0, count);
                        }
                        response = output.toString("UTF-8");
                    }
                } catch (Exception error) {
                    try { response = new JSONObject().put("error", error.getMessage() == null ? "Connection error" : error.getMessage()).toString(); }
                    catch (Exception ignored) { response = "{\"error\":\"Connection error\"}"; }
                } finally { if (connection != null) connection.disconnect(); }
                evaluate("window.ASPLAYER_REPLY(" + JSONObject.quote(id) + "," + JSONObject.quote(response) + ");");
            });
        }
    }


    @Override public void onConfigurationChanged(Configuration c) {super.onConfigurationChanged(c);updateAspect();}
    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if(focus && playerVisible)getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE);
    }
    @Override public void onBackPressed() {
        if(playerVisible)closePlayer(true);
        else evaluate("window.ASPLAYER_BACK&&window.ASPLAYER_BACK();");
    }
    @Override protected void onStop() {
        if(playerVisible&&player!=null){sendPosition(false);player.pause();}
        super.onStop();
    }
    @Override protected void onDestroy() {
        closePlayer(false);
        if(player!=null) {
            if(attached)player.detachViews();
            player.release();player=null;
        }
        if(vlc!=null){vlc.release();vlc=null;}
        requests.shutdownNow();
        if(web!=null)web.destroy();
        super.onDestroy();
    }
}
