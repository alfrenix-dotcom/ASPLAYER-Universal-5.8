/* ASPLAYER Universal 5.8: LibVLC route and native watch progress.
   Installed only with the corresponding LibVLC Android bridge. */
(function(){
'use strict';
const bridge=window.ASPLAYER;
if(!bridge || typeof bridge.playMedia!=='function'){
  console.warn('ASPLAYER 5.8: LibVLC bridge unavailable, preserving 5.7.1 playback');
  return;
}
const get=id=>document.getElementById(id);
let currentItem=null,currentMode=null,currentId='',currentPrefix='',nativeVisible=false;
const idOf=item=>String(item?.stream_id??item?.series_id??item?.id??item?.name??'');
const oldPlay=play;
play=function(item,mode){
  currentItem=item;
  currentMode=mode;
  currentId=idOf(item);
  currentPrefix=sessionPrefix();
  try{bridge.setPlaybackOptions(settings.bufferProfile||'normal',playAspect,audioPref,subsPref)}catch(_){ }
  return oldPlay(item,mode);
};
function record(){
  const all=load(HISTORY_KEY,{});
  const data=all[currentPrefix]||{};
  const rows=Array.isArray(data[currentMode])?data[currentMode]:[];
  const i=rows.findIndex(x=>String(x.id)===String(currentId));
  return {all,data,rows,i};
}
function rememberNativeProgress(ms,durationMs,ended){
  if(!currentId||!currentPrefix||!['vod','series'].includes(currentMode))return;
  const pos=Number(ms)/1000,dur=Number(durationMs)/1000;
  if(!Number.isFinite(pos)||pos<0)return;
  const state=record();
  if(state.i<0)return;
  const row=state.rows.splice(state.i,1)[0];
  row.position=Math.max(0,pos);
  if(Number.isFinite(dur)&&dur>0)row.duration=dur;
  row.watchedAt=Date.now();
  row.finished=Boolean(ended)||(row.duration>0&&row.position/row.duration>=0.96);
  state.rows.unshift(row);
  state.data[currentMode]=state.rows.slice(0,300);
  state.all[currentPrefix]=state.data;
  store(HISTORY_KEY,state.all);
  if(typeof renderWatchPanels==='function')renderWatchPanels();
}
window.ASPLAYER58_EVENT=function(event){
  if(!event||!event.type)return;
  if(event.type==='position'){
    rememberNativeProgress(event.position,event.duration,event.ended);
  }else if(event.type==='ended'){
    /* Final position arrives in the preceding position event. */
  }else if(event.type==='closed'){
    nativeVisible=false;
    stopPlayer();
  }else if(event.type==='error'){
    toast(tr('playerFailure'));
  }
};
const prevOpenPlayer=openPlayer;
openPlayer=function(){
  if(!playback||!currentItem)return prevOpenPlayer();
  const r=record(),row=r.i>=0?r.rows[r.i]:null;
  const resume=Number(row?.position)||0;
  try{
    get('player-choice').classList.add('hidden');
    get('modern-player').classList.add('hidden');
    nativeVisible=true;
    bridge.playMedia(playback.url, settings.bufferProfile||'normal',playAspect,
                     audioPref,subsPref,Math.round(resume*1000));
  }catch(error){
    nativeVisible=false;
    return prevOpenPlayer();
  }
};
const prevStop=stopPlayer;
stopPlayer=function(){
  if(nativeVisible){
    nativeVisible=false;
    try{bridge.stopMedia()}catch(_){ }
  }
  prevStop();
};
const settingsHint=document.createElement('p');
settingsHint.className='tiny';
settingsHint.textContent=lang==='es'
  ?'ASPLAYER 5.8 usa LibVLC/VLC para TV, películas y series. Selecciona pistas disponibles desde los controles nativos del reproductor.'
  :'ASPLAYER 5.8 uses LibVLC/VLC for live TV, films and series. Choose available audio/subtitle tracks in the native player controls.';
const playerSetting=get('preferred-player')?.closest('.setting');
if(playerSetting)playerSetting.appendChild(settingsHint);
const about=Array.from(document.querySelectorAll('#view-settings p'))
  .find(el=>el.textContent.includes('ASPLAYER Universal 5.7.1'));
if(about)about.textContent='ASPLAYER Universal 5.8.1 · LibVLC/VLC · Alftech Solutions';
const refreshLanguage=languageUI;
languageUI=function(){
  refreshLanguage();
  settingsHint.textContent=lang==='es'
    ?'LibVLC/VLC está configurado para TV, películas y series. Los idiomas y subtítulos disponibles se eligen en el reproductor.'
    :'LibVLC/VLC is configured for live TV, movies and series. Choose available tracks in the player.';
};
console.info('ASPLAYER 5.8 LibVLC bridge active');
})();
