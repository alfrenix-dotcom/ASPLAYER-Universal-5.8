/* ASPLAYER 5.7.1: no-EPG live TV, account-scoped favourites and watch progress,
   and three playback preferences. Only real provider/device tracks are shown.
   The Android VideoView engine cannot guarantee target buffer seconds. */
(function(){
'use strict';
const G=id=>document.getElementById(id);
const words={
 en:{favourites:'Favorites',favourite:'Add to favorites',removeFavourite:'Remove from favorites',noFavourites:'Mark a channel with ☆ to see it here.',continueWatching:'Continue watching',viewHistory:'History',watchEmpty:'Nothing watched yet',resume:'Resume',fromStart:'From beginning',watched:'Watched',watchProgress:'Playback progress',watchNote:'Resume positions are saved for supported in-app playback. Android/external players may not report position.',bufferProfiles:'Playback stability',bufferProfilesHelp:'Choose a startup/recovery preference. Actual buffer duration and startup time depend on Android and your provider.',fastProfile:'FAST · lower latency',normalProfile:'NORMAL · balanced (default)',ultraProfile:'ULTRA · stability first',fastInfo:'Prioritizes startup speed; no fixed 1-second guarantee.',normalInfo:'Balanced preloading preference; 4 seconds is a target, not a guaranteed buffer.',ultraInfo:'Stability preference; an 8–10 second RAM buffer requires a capable native player.',tracksExternal:'Open in an external player for more audio/subtitle options',historyEpisode:'Episode',allFaves:'Favorite channels'},
 es:{favourites:'Favoritos',favourite:'Agregar a favoritos',removeFavourite:'Quitar de favoritos',noFavourites:'Marca un canal con ☆ para verlo aquí.',continueWatching:'Seguir viendo',viewHistory:'Historial',watchEmpty:'Todavía no has visto contenido',resume:'Continuar',fromStart:'Desde el inicio',watched:'Visto',watchProgress:'Progreso de reproducción',watchNote:'El progreso se guarda en el reproductor integrado cuando el formato lo permite. Android y los reproductores externos podrían no informar la posición.',bufferProfiles:'Estabilidad de reproducción',bufferProfilesHelp:'Elige una preferencia de inicio y recuperación. La duración real del búfer y la apertura dependen de Android y del servidor.',fastProfile:'RÁPIDO · baja latencia',normalProfile:'NORMAL · equilibrado (predeterminado)',ultraProfile:'ULTRA · máxima estabilidad',fastInfo:'Da prioridad a abrir rápido; no garantiza iniciar en 1 segundo.',normalInfo:'Prefiere la precarga equilibrada; 4 segundos es un objetivo, no un búfer garantizado.',ultraInfo:'Prefiere estabilidad; mantener 8–10 segundos en RAM exige un reproductor nativo compatible.',tracksExternal:'Abrir en otro reproductor para más opciones de audio y subtítulos',historyEpisode:'Capítulo',allFaves:'Canales favoritos'}
};
for(const langKey of ['en','es'])Object.assign(LABELS[langKey],words[langKey]);
LABELS.en.onlineHint='Optional HTTPS service for AI synopses and announcements. Do not enter OpenAI API keys here.';
LABELS.es.onlineHint='Servicio HTTPS opcional para sinopsis por IA y avisos. No introduzcas claves de OpenAI aquí.';
const FAVORITES_KEY='asplayer:favorites:v571';
const getPrefix=()=>sessionPrefix();
function accountStore(key){const all=load(key,{});return Array.isArray(all[getPrefix()])?all[getPrefix()]:[]}
function writeAccountStore(key,rows){const all=load(key,{});all[getPrefix()]=rows;store(key,all)}
function contentId(it){return String(it?.stream_id??it?.series_id??it?.id??it?.name??'')}
function favouriteItems(){return accountStore(FAVORITES_KEY)}
function favouriteId(it){return String(it.stream_id??it.id??'')}
function favHas(it){return favouriteItems().some(x=>favouriteId(x)===favouriteId(it))}
function cleanItem(it){const allowed=['stream_id','series_id','id','category_id','name','title','container_extension','stream_icon','cover','movie_image','added','episode_num','season','seriesName','seriesId'];const out={};for(const k of allowed)if(it&&it[k]!=null)out[k]=it[k];return out}
function toggleFavourite(it){
 if(!it?.stream_id)return;
 let rows=favouriteItems().filter(x=>favouriteId(x)!==favouriteId(it));
 if(!favHas(it))rows.unshift(cleanItem(it));
 writeAccountStore(FAVORITES_KEY,rows.slice(0,400));
 if(category==='favorites'&&active==='live')loadFavoriteList();
 else if(active==='live')renderItems();
 renderFavoritePreview();renderCats();
}
const favPreview=document.createElement('section');favPreview.id='favorite-preview';favPreview.className='box fav-preview hidden';
G('category-tools').before(favPreview);
function favTile(it,i){const image=safeImage(it.stream_icon||it.cover);return `<button class="fav-quick" data-fav-play="${i}">${image?`<img src="${esc(image)}" alt="" loading="lazy" onerror="this.style.display='none'">`:'<span>📺</span>'}<small>${esc(it.name||it.title||'Channel')}</small></button>`}
function renderFavoritePreview(){
 const show=active==='live'&&!!session();favPreview.classList.toggle('hidden',!show);if(!show)return;
 const items=favouriteItems();favPreview.innerHTML=`<div class="fav-header"><strong>★ ${esc(tr('allFaves'))} (${items.length})</strong><button type="button" class="ghost" data-open-faves>${esc(tr('favourites'))}</button></div>`+(items.length?`<div class="fav-rail">${items.slice(0,12).map(favTile).join('')}</div>`:`<p class="tiny">${esc(tr('noFavourites'))}</p>`);
}
favPreview.addEventListener('click',event=>{
 if(event.target.closest('[data-open-faves]'))return tryCategory('favorites');
 const btn=event.target.closest('[data-fav-play]');if(!btn)return;
 const it=favouriteItems()[Number(btn.dataset.favPlay)];if(it)play(it,'live');
});
function loadFavoriteList(){category='favorites';filter='';visible=32;G('search').value='';catalog=favouriteItems();filtered=catalog.slice();renderCats();renderItems();}
const historicalRenderCats=renderCats;
renderCats=function(){historicalRenderCats();if(active!=='live')return;const wrap=G('categories');const btn=document.createElement('button');btn.type='button';btn.className='tab fav-tab'+(category==='favorites'?' active':'');btn.dataset.category='favorites';btn.textContent='★ '+tr('favourites')+' ('+favouriteItems().length+')';wrap.prepend(btn);renderFavoritePreview()};
const historicalTryCategory=tryCategory;
tryCategory=function(id){if(id==='favorites'&&active==='live')return loadFavoriteList();return historicalTryCategory(id)};
const historicalRenderItems=renderItems;
renderItems=function(){historicalRenderItems();if(active!=='live')return;const nodes=Array.from(G('cards').querySelectorAll('button[data-item]'));
 nodes.forEach(tile=>{const item=filtered[Number(tile.dataset.item)];if(!item?.stream_id)return;
  const wrap=document.createElement('div');wrap.className='fav-tile';tile.before(wrap);wrap.appendChild(tile);
  const star=document.createElement('button');star.type='button';star.className='fav-star'+(favHas(item)?' selected':'');star.dataset.favIndex=tile.dataset.item;
  star.textContent=favHas(item)?'★':'☆';star.setAttribute('aria-label',tr(favHas(item)?'removeFavourite':'favourite'));star.setAttribute('aria-pressed',String(favHas(item)));wrap.appendChild(star);
 });
};
G('cards').addEventListener('click',event=>{const star=event.target.closest('[data-fav-index]');if(!star)return;event.stopPropagation();event.preventDefault();const item=filtered[Number(star.dataset.favIndex)];if(item)toggleFavourite(item);},true);

// Existing HISTORY_KEY and localStorage format are preserved across updates.
function getHistory(mode){const all=load(HISTORY_KEY,{});const set=all[getPrefix()]||{};return Array.isArray(set[mode])?set[mode]:[]}
function putHistory(mode,rows){const all=load(HISTORY_KEY,{}),prefix=getPrefix();const record=all[prefix]&&typeof all[prefix]==='object'?all[prefix]:{live:[],vod:[],series:[]};record[mode]=rows.slice(0,300);all[prefix]=record;store(HISTORY_KEY,all)}
function findRow(mode,id){return getHistory(mode).find(x=>String(x.id)===String(id))}
let currentSeries=null,nowPlaying=null,pendingResume=0,lastProgressSave=0;
const historicalShowSeries=showSeries;
showSeries=function(it){currentSeries=cleanItem(it);return historicalShowSeries(it)};
const historicalRemember=rememberPlay;
rememberPlay=function(mode,it){
 const id=contentId(it),prev=findRow(mode,id),item=cleanItem(it);
 if(mode==='series'&&currentSeries){item.seriesName=item.seriesName||currentSeries.name;item.seriesId=item.seriesId||currentSeries.series_id;}
 historicalRemember(mode,it);
 const rows=getHistory(mode).filter(x=>String(x.id)!==id);
 const title=mode==='series'&&item.seriesName?`${item.seriesName} · ${it.title||it.name||tr('historyEpisode')}`:String(it.title||it.name||'');
 rows.unshift({...prev,id,mode,title,watchedAt:Date.now(),item,
  position:Number(prev?.position)||0,duration:Number(prev?.duration)||0});
 putHistory(mode,rows);
};
function writeProgress(force=false,ended=false){
 if(!nowPlaying||!['vod','series'].includes(nowPlaying.mode)||!session())return;
 const v=G('video');if(v?.readyState<1)return;
 const pos=Number(v.currentTime);if(!Number.isFinite(pos)||pos<0)return;
 if(!force&&Date.now()-lastProgressSave<5000)return;
 const dur=Number(v.duration),rows=getHistory(nowPlaying.mode),i=rows.findIndex(x=>String(x.id)===nowPlaying.id);
 if(i<0)return;
 const row=rows.splice(i,1)[0];row.position=ended?(Number.isFinite(dur)?dur:pos):pos;
 if(Number.isFinite(dur)&&dur>0)row.duration=dur;
 row.watchedAt=Date.now();row.finished=ended||(row.duration>0&&row.position/row.duration>=.96);
 rows.unshift(row);putHistory(nowPlaying.mode,rows);lastProgressSave=Date.now();
}
const historyPlay=play;
play=function(it,mode){
 if(mode==='series'&&it?.seriesName&&!currentSeries)currentSeries={name:it.seriesName,series_id:it.seriesId};
 nowPlaying=['vod','series'].includes(mode)?{mode,id:contentId(it)}:null;
 historyPlay(it,mode);lastProgressSave=0;renderWatchPanels();
};
const historyOpenPlayer=openPlayer;
openPlayer=function(){historyOpenPlayer();if(!nowPlaying)return;
 const row=findRow(nowPlaying.mode,nowPlaying.id),position=pendingResume||Number(row?.position)||0;
 pendingResume=0;
 if(position>5){const v=G('video');const restore=()=>{
   if(!nowPlaying||v.readyState<1)return;
   try{if(!Number.isFinite(v.duration)||position<v.duration-3)v.currentTime=position}catch(_){}
   v.removeEventListener('loadedmetadata',restore);
  };v.addEventListener('loadedmetadata',restore,{once:true});if(v.readyState>=1)restore();}
};
const historyStopPlayer=stopPlayer;
stopPlayer=function(){writeProgress(true);historyStopPlayer();nowPlaying=null;renderWatchPanels()};
const v=G('video');v.addEventListener('timeupdate',()=>writeProgress());v.addEventListener('pause',()=>writeProgress(true));v.addEventListener('ended',()=>{writeProgress(true,true);renderWatchPanels()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)writeProgress(true)});
const watchPanels=document.createElement('section');watchPanels.id='watch-panels';watchPanels.className='watch-panels hidden';G('view-catalog').querySelector('.sectionhead').after(watchPanels);
function watchCard(row,index,collection){
 const image=safeImage(row.item?.stream_icon||row.item?.cover||row.item?.movie_image),duration=Number(row.duration)||0,position=Number(row.position)||0,pct=duration?Math.max(0,Math.min(100,100*position/duration)):0;
 const label=row.title||row.item?.name||row.item?.title||tr('watched');
 return `<button class="watch-card" data-watch-group="${collection}" data-watch-index="${index}"><span class="watch-image">${image?`<img src="${esc(image)}" loading="lazy" alt="" onerror="this.style.display='none'">`:'▶'}</span><strong>${esc(label)}</strong>${position>0?`<small>${esc(fmtTime(position))}${duration?' / '+esc(fmtTime(duration)):''}</small>`:''}<span class="watch-meter"><i style="width:${pct.toFixed(1)}%"></i></span></button>`;
}
function renderWatchPanels(){
 const tab=active,visiblePanel=(tab==='vod'||tab==='series')&&!!session();watchPanels.classList.toggle('hidden',!visiblePanel);if(!visiblePanel)return;
 const history=getHistory(tab).filter(x=>x.item&&contentId(x.item)),continueRows=history.filter(x=>Number(x.position)>8&&!x.finished&&(Number(x.duration)<=0||Number(x.position)/Number(x.duration)<.96));
 watchPanels._rows={continue:continueRows,history};
 watchPanels.innerHTML=`<h3>▶ ${esc(tr('continueWatching'))}</h3><div class="watch-row">${continueRows.length?continueRows.slice(0,14).map((x,i)=>watchCard(x,i,'continue')).join(''):`<p class="tiny">${esc(tr('watchEmpty'))}</p>`}</div><h3>◷ ${esc(tr('viewHistory'))}</h3><div class="watch-row">${history.length?history.slice(0,30).map((x,i)=>watchCard(x,i,'history')).join(''):`<p class="tiny">${esc(tr('watchEmpty'))}</p>`}</div><p class="tiny">${esc(tr('watchNote'))}</p>`;
}
watchPanels.addEventListener('click',event=>{
 const button=event.target.closest('[data-watch-index]');if(!button)return;
 const group=button.dataset.watchGroup,rows=watchPanels._rows?.[group]||[],row=rows[Number(button.dataset.watchIndex)];if(!row?.item)return;
 pendingResume=Number(row.position)||0;
 if(row.mode==='series')currentSeries={name:row.item.seriesName||'',series_id:row.item.seriesId||''};
 play(row.item,row.mode);
});
const historicalShowTab=showTab;
showTab=function(tab){historicalShowTab(tab);renderWatchPanels();renderFavoritePreview()};
const historicalSwitch=switchToServer;
switchToServer=function(index){writeProgress(true);historicalSwitch(index);renderWatchPanels();renderFavoritePreview()};
const historicalClear=clearHistory;
clearHistory=function(mode){historicalClear(mode);renderWatchPanels()};

// No EPG, guide, channel loading labels, or old buffering toggle visible.
const oldSetting=G('buffer-enabled')?.closest('.buffer-setting');if(oldSetting)oldSetting.classList.add('hidden');
const epgSource=G('epg-source');if(epgSource){const section=epgSource.closest('.setting');if(section)section.classList.add('hidden')}
for(const id of ['player-epg','player-mini','live-guide-pane','epg-panel','epg-standalone','buffer-state','native-guide-status']){const el=G(id);if(el)el.classList.add('hidden')}
window.ASPLAYER_NATIVE_MINI=()=>{stopPlayer()};
// A small settings selector. VideoView controls its own actual buffer; these are
// preferences, not measured/guaranteed durations.
let bufferProfile=['fast','normal','ultra'].includes(settings.bufferProfile)?settings.bufferProfile:'normal';
const playerBox=G('preferred-player')?.closest('.setting');
if(playerBox){const profileBox=document.createElement('div');profileBox.className='box setting';profileBox.id='profile-settings';playerBox.after(profileBox);const draw=()=>{
 profileBox.innerHTML=`<h3>${esc(tr('bufferProfiles'))}</h3><p>${esc(tr('bufferProfilesHelp'))}</p>`+['fast','normal','ultra'].map((type)=>`<label class="profile-choice"><input name="play-profile" type="radio" value="${type}" ${type===bufferProfile?'checked':''}><span><strong>${esc(tr(type+'Profile'))}</strong><small>${esc(tr(type+'Info'))}</small></span></label>`).join('');
 };
 profileBox.addEventListener('change',e=>{if(!e.target.matches('input[name=play-profile]'))return;bufferProfile=e.target.value;settings.bufferProfile=bufferProfile;store(SETTINGS_KEY,settings);
  const oldToggle=G('buffer-enabled');if(oldToggle){oldToggle.checked=bufferProfile!=='fast';oldToggle.dispatchEvent(new Event('change',{bubbles:true}));}
 });
 const oldLanguage=languageUI;languageUI=function(){oldLanguage();draw();renderWatchPanels();renderFavoritePreview()};draw();
}
// HTML5 can expose audioTracks/textTracks on some devices; if not, an installed
// native/external player may expose the embedded alternatives.
const externalTrackButton=document.createElement('button');externalTrackButton.type='button';externalTrackButton.className='ghost';externalTrackButton.id='tracks-external';G('player-track-panel').appendChild(externalTrackButton);
function trackHelp(){externalTrackButton.textContent=tr('tracksExternal');externalTrackButton.classList.toggle('hidden',!playback||playback.mode==='live')}
externalTrackButton.addEventListener('click',()=>{const url=playback?.url;if(url){writeProgress(true);externalPlay(url)}});
const prevTracks=updateTracks;updateTracks=function(){prevTracks();trackHelp()};
// Some devices discover embedded tracks after metadata, not at its first event.
const videoTracks=G('video');for(const kind of ['audioTracks','textTracks']){
 const list=videoTracks[kind];if(list&&typeof list.addEventListener==='function'){
  list.addEventListener('addtrack',()=>updateTracks());list.addEventListener('removetrack',()=>updateTracks());
 }
}
videoTracks.addEventListener('canplay',()=>updateTracks());
const css=document.createElement('style');css.textContent=`
#live-guide-pane,#player-epg,#player-mini,#epg-panel,#epg-standalone,#buffer-state,#native-guide-status,.buffer-setting,.guide-button{display:none!important}
.fav-preview{padding:14px 16px;margin:10px 0 16px}.fav-header{display:flex;justify-content:space-between;align-items:center;gap:10px}.fav-rail{display:flex;gap:9px;overflow-x:auto;margin-top:12px}.fav-quick{background:#12213e;border:1px solid #345578;border-radius:11px;width:100px;min-width:100px;padding:8px;color:#d9efff;overflow:hidden}.fav-quick img{height:54px;max-width:100%;object-fit:contain}.fav-quick span{font-size:23px;display:block}.fav-quick small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fav-tile{position:relative;display:flex;flex-direction:column;min-width:0}.fav-tile .tile{flex:1}.fav-star{position:absolute;right:7px;top:7px;background:#0c1d38ef;color:#dffaff;border:1px solid #5a7ca4;border-radius:22px;font-size:22px;min-width:44px;min-height:44px;padding:4px;z-index:1}.fav-star.selected{color:#ffdc73;border-color:#ffdc73}.watch-panels{margin:14px 0 24px}.watch-panels h3{font-size:17px;margin:17px 0 9px}.watch-row{display:flex;gap:10px;overflow:auto;padding-bottom:6px}.watch-card{width:135px;min-width:135px;text-align:left;border:1px solid #405675;border-radius:12px;background:#111f38;overflow:hidden;padding:7px}.watch-card .watch-image{height:70px;display:flex;align-items:center;justify-content:center;background:#203052;font-size:30px}.watch-card .watch-image img{height:70px;width:100%;object-fit:cover}.watch-card strong{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:12px;min-height:31px;margin-top:5px}.watch-card small{font-size:11px;color:#bdd6e9;display:block}.watch-meter{display:block;height:4px;border-radius:4px;background:#375072;margin-top:5px}.watch-meter i{display:block;height:100%;border-radius:4px;background:#65dcdb}.profile-choice{display:flex;gap:12px;align-items:center;border:1px solid #3a5170;border-radius:12px;padding:12px;margin:8px 0}.profile-choice input{width:19px;height:19px;min-height:19px;flex:none;accent-color:#6edddd}.profile-choice small{display:block;color:#b7c8df;font-size:11px;margin-top:4px}
`;document.head.appendChild(css);
languageUI();renderWatchPanels();renderFavoritePreview();trackHelp();
console.info('ASPLAYER 5.7.1 favorites, history, resume, no EPG, player preferences');
})();
