# 5.8.1 LibVLC experimental variant
- Replaced Media3 native player implementation with LibVLC 3.7.7 in MainActivity.
- Added native audio/subtitle selection, hide-after-3-seconds controls, caching options.
- Kept 5.7.1 catalog/favorites/progress UI and independent login.
- Package `com.alftech.asplayer.universal.vlc` for side-by-side testing.
- Source only. No runtime or build verification. IPTV Smarters Pro proprietary software is NOT included.
