# ASPLAYER Universal 5.8.2 — experimental LibVLC playback

**Status: source project, not an APK. Not built, not validated on real devices.**

This is an alternative to Media3, **not a clone or licensed modification of IPTV Smarters Pro**. It uses the separate, open-source **LibVLC 3.7.7** library (`org.videolan.android:libvlc-all:3.7.7`) from Maven Central. Check and comply with its LGPL license obligations before distributing APKs.

## Included

- ASPLAYER 5.7.1 front-end and account flow, servers, catalogues, favorites, Continue Watching and viewing history from the 5.8 source base.
- Native LibVLC streaming player for live TV, movies and series. HLS, MPEG-TS and supported MP4/MKV codecs depend on stream and device.
- Native Android overlay with audio/subtitle track menus, pause/seek, scale adjustment, auto-hide after three seconds, and position callbacks for viewing history.
- Live MPEG-TS fallback for `.m3u8` failures; single attempt only.
- Three **network caching suggestions**, not guaranteed startup speeds: Fast 1000ms, Normal 4000ms (default), Ultra 9000ms.
- A **separate package ID** `com.alftech.asplayer.universal.vlc.full` so a test APK may be installed beside the existing 5.7.1 app without uninstalling or losing its data. Saved sessions are separate.
- WebView XTream requests and existing original ASPLAYER UI continue with known server hosts.

## Build in Android Studio or GitHub Actions

- Requires Java 17, Android SDK Platform 35 and Gradle 8.11.1.
- LibVLC packages are downloaded through Maven Central when compiling. The binary AAR is **not included** in this source archive. A built APK will be substantially larger than the old ~5.5 MB ASPLAYER package.
- Open this folder as a Gradle project and run **Build APK(s)**. Alternatively upload the project files, including `.github`, to the root of a **private GitHub repository**. In Actions run **Build ASPLAYER 5.8 LibVLC APK**, then download the artifact **ASPLAYER-5.8.2-LibVLC-APK** after a successful run.
- Gradle execution, native library linkage and runtime playback have **not been verified in this environment**. Errors exposed by an actual build still need correction.

## What must be tested

Login in ANUBIS, DIAMOND and DIAMOND 2 without sharing credentials; HLS and MPEG-TS; MP4/MKV with alternate audio; subtitles; rotate phone; playback controls on Android TV DPAD; Fast/Normal/Ultra; interrupted Wifi; resume playback; favorites/history and Android 16.

## Important notes

- Track selectors enumerate only tracks that LibVLC exposes for the playing stream. They do not invent alternate soundtracks or subtitles.
- Three caching numbers are LibVLC options, **not promises** that a channel opens in one second or that there are no interruptions.
- The original Xtream servers are HTTP. Credentials and playback URLs remain unencrypted in transit. The legacy session storage was not migrated to secure Android Keystore in this prototype.
- There is no EPG UI or EPG fetching in the player.
- Commercial distribution must include any applicable attribution and LGPL compliance obligations for VideoLAN software.
